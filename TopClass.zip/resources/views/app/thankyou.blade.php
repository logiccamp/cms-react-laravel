<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THANK YOU - TOP CLASS CARPETS</title>
</head>

<body>
    <h1>Thank you for your message. We will get back to you shortly</h1>
    <a href="/">go back</a>
</body>

</html>